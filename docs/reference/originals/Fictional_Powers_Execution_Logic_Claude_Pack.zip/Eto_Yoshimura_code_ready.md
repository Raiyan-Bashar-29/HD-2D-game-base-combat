# Eto Yoshimura — V3 Character Execution Logic

All ability algorithms are proposals to adapt to your selected game engine. **Kakuja is a form; Ukaku is the kagune type.**

# Eto Yoshimura — Claude-ready character specification

**Setting:** Tokyo Ghoul
**Species:** natural one-eyed ghoul
**Threat rating:** SSS-rated (One-Eyed Owl)
**Roles:** ranged_burst, melee_bruiser, transformation_boss, sustain

## Forms

- **normal** — Humanlike form; can manifest and reshape ukaku kagune.
- **kagune_manifested** — Multiple back-mounted kagune appendages; projectile and appendage attacks.
- **kakuja_form** — Massive Owl-like kakuja form; retains tactical awareness.

## Ukaku RC Shard Volley
**Canon:** Eto uses her ukaku kagune to fire destructive Rc-cell projectiles from her kagune, suited to middle and longer ranges.
**Action type:** ranged_attack
**Activation:** active
**Target:** visible foe(s) in front / ranged line
**Required form:** none_specified
**Effect:** Multiple fast penetrating-looking projectiles, Pressure on blocking opponents

**Implementation suggestions (not canon):**
- Confirm the kagune is manifested.
- Play windup from back appendages; release several owned RC-shard projectiles.
- On each projectile hit, use collision resolver; allow separate hit behavior per target.
- Enter attack recovery without automatically disabling the kagune.
**Limits and unknowns:** Number, spread, speed and damage of projectiles are NOT specified as fixed canonical values.

## Adaptive Kagune Appendages
**Canon:** Eto reshapes her kagune into grotesque limbs, eyes, mouths and other appendages; her shapes are not constrained to a simple wing.
**Action type:** morphing_melee
**Activation:** active_or_continuous
**Target:** self / nearby enemies
**Required form:** none_specified
**Effect:** Change appendage geometry, Reach, strike, grasp and sensory-form expression

**Implementation suggestions (not canon):**
- Represent kagune as attachable segments with form variants.
- State-driven shape transitions: limb, jaw/mouth, sensory eye, strike arm.
- Move hitboxes with rigged segments; activate grapples and strikes only on qualifying animation frames.
**Limits and unknowns:** Speaking mouths and unusual forms are depicted; assigning independent vision or sentient AI to each appendage requires separate design choice.

## Kakuja: One-Eyed Owl
**Canon:** Eto can deploy a monstrous armored kakuja body while retaining consciousness, increasing reach and access to large close-range attacks.
**Action type:** transformation
**Activation:** active_transformation
**Target:** self
**Required form:** normal_or_kagune_manifested
**Effect:** Large transformed body, Altered armor/model and melee techniques, Retains conscious tactical control

**Implementation suggestions (not canon):**
- Check if transformation is allowed, transition normal -> kakuja.
- Swap rigs, collision capsules/hitbox sets, attack loadout and animations.
- Do not assume the transformation causes loss of player/AI control.
- Leave transformation when explicitly canceled or story/game state requires.
**Limits and unknowns:** Transformation prerequisites, duration and cooldown are not canonically quantified.

## Kakuja Heavy Cleave
**Canon:** Eto uses the large, reshaped kakuja body to cut down nearby opponents with close-range attacks.
**Action type:** melee_attack
**Activation:** active
**Target:** short-range enemies near front arc
**Required form:** kakuja_form
**Effect:** Large melee damage zone, Heavy knockback only if separately designed

**Implementation suggestions (not canon):**
- Require kakuja_form.
- Select heavy-swing animation and trace a broad moving hitbox.
- Resolve contacts once per swing; allow collision with environment if configured.
**Limits and unknowns:** No fixed numeric hitbox size, knockback or damage is provided by canon.

## Detached Kagune Restraint
**Canon:** Eto detaches pieces of kagune that can act away from her body and restrain or manipulate a target.
**Action type:** remote_control
**Activation:** active
**Target:** selected nearby or remotely reachable enemy
**Required form:** none_specified
**Effect:** Detach and animate kagune fragment, Remote grapple or bind

**Implementation suggestions (not canon):**
- Spawn an owned detachable kagune entity rather than a simple thrown item.
- Give it travel, seek or placed behavior and a restraint collision trigger.
- While attached, apply movement/action restrictions and enable escape/counter rules if game design allows.
- Clean up fragment if destroyed or recalled.
**Limits and unknowns:** Exact autonomy, lifetime, target range and escape threshold remain unspecified.

## Kagune Transplant / RC Alteration
**Canon:** Eto is shown introducing kagune tissue into others and altering their physiology; mechanism and outcomes are unusually complex and case-specific.
**Action type:** biological_modification
**Activation:** special_scripted_interaction
**Target:** specific other individual
**Required form:** none_specified
**Effect:** Possible physiological alteration / RC-pattern influence

**Implementation suggestions (not canon):**
- Do not implement as an unconditional damaging projectile.
- Treat as a scripted target-dependent transformation with explicit permission, scenario and valid recipients.
- Model the result as a status/character modification only when the game designer defines which characters are eligible.
**Limits and unknowns:** Not a universally confirmed instant conversion ability; exact mechanics are uncertain and must not be generalized.

## Ghoul Regeneration
**Canon:** Eto survives extreme bodily injury and regenerates significant portions of her body under story-specific conditions.
**Action type:** passive_sustain
**Activation:** passive
**Target:** self
**Required form:** none_specified
**Effect:** Recover serious injuries, Regrow damaged tissue

**Implementation suggestions (not canon):**
- Use a dedicated regen component attached to her ghoul biology.
- Expose regen rate and what injuries are repairable as tunable parameters.
- Tie extreme events to scripted regeneration states rather than instant immortality.
**Limits and unknowns:** Do not infer infinite regeneration, zero cost or invulnerability.

## Superhuman Speed and Resilience
**Canon:** Eto moves too quickly for some opponents to visually track and endures extremely serious impacts.
**Action type:** passive_stats
**Activation:** passive
**Target:** self
**Required form:** none_specified
**Effect:** Enhanced mobility, High durability and evasive performance

**Implementation suggestions (not canon):**
- Apply character movement and hit-reaction modifiers as a stat profile.
- Allow tactical AI reposition and evasive movement.
**Limits and unknowns:** Canon does not supply numeric speed/durability multipliers.

## Verified references
- https://tokyoghoul.fandom.com/wiki/Eto_Yoshimura
- https://tokyoghoul.fandom.com/wiki/Kagune

**Note:** All numerical combat values remain unspecified; Claude must not infer them as canon.


---

# NEW — Individual Move Coding Logic

## 1. Ukaku RC Shard Volley

**Canon effect:** Eto uses her ukaku kagune to fire destructive Rc-cell projectiles from her kagune, suited to middle and longer ranges.

**Activation:** active · **Form:** none_specified · **Targeting:** visible foe(s) in front / ranged line

**Coding logic**

- CHARACTER: Eto Yoshimura — Ukaku RC Shard Volley
- CANON BEHAVIOR: Eto uses her ukaku kagune to fire destructive Rc-cell projectiles from her kagune, suited to middle and longer ranges.
- FORM REQUIREMENT: none_specified
- Confirm the kagune is manifested.
- Play windup from back appendages; release several owned RC-shard projectiles.
- On each projectile hit, use collision resolver; allow separate hit behavior per target.
- Enter attack recovery without automatically disabling the kagune.
- IMPLEMENTATION FAMILY: Ukaku RC shard volley
- assert actor.has_kagune_type(UKAKU) and actor.kagune_is_active
- for direction in spread_vectors(aim, shard_count, spread_angle):
-     shard = spawn_rc_shard(actor.kagune_socket, direction, owner=actor)
-     shard.on_collision = lambda target: hit_resolver.resolve(shard, target)
-     shard.expire_after(range_or_lifetime)
- Use fire/burn material tags; a damage-over-time status is optional unless explicitly described.
- Emit effect/VFX events and run interruption, expiry and cleanup handlers.

**Engine-neutral pseudocode**

```text
def execute_ukaku_rc_shard_volley_tokyo(ctx, actor, target, cfg):
    # LORE INTENT: Eto uses her ukaku kagune to fire destructive Rc-cell projectiles from her kagune, suited to middle and longer ranges.
    if not ctx.owns_ability(actor, ability_id): return NOT_OWNED
    if not ctx.check_explicit_conditions(actor, target, cfg): return DENIED
    tx = ctx.begin_effect(ability_id, actor, target)
    assert actor.has_kagune_type(UKAKU) and actor.kagune_is_active
    for direction in spread_vectors(aim, shard_count, spread_angle):
        shard = spawn_rc_shard(actor.kagune_socket, direction, owner=actor)
        shard.on_collision = lambda target: hit_resolver.resolve(shard, target)
        shard.expire_after(range_or_lifetime)
    tx.commit_if_valid()
    ctx.emit_effect_event(ability_id)
    return SUCCESS
```

**Undefined balancing inputs:** shard_count, spread_angle, range, projectile_speed, cooldown, resource_cost, duration

## 2. Adaptive Kagune Appendages

**Canon effect:** Eto reshapes her kagune into grotesque limbs, eyes, mouths and other appendages; her shapes are not constrained to a simple wing.

**Activation:** active_or_continuous · **Form:** none_specified · **Targeting:** self / nearby enemies

**Coding logic**

- CHARACTER: Eto Yoshimura — Adaptive Kagune Appendages
- CANON BEHAVIOR: Eto reshapes her kagune into grotesque limbs, eyes, mouths and other appendages; her shapes are not constrained to a simple wing.
- FORM REQUIREMENT: none_specified
- Represent kagune as attachable segments with form variants.
- State-driven shape transitions: limb, jaw/mouth, sensory eye, strike arm.
- Move hitboxes with rigged segments; activate grapples and strikes only on qualifying animation frames.
- IMPLEMENTATION FAMILY: Melee animation with active frames
- assert allowed_combat_state(actor)
- play_attack_animation(actor,ability)
- during_active_frames: targets = sweep_weapon_or_body_hitbox(actor)
- for target in new_valid_targets(targets,hit_ledger): resolve_melee_hit(target)
- on_recovery_complete: disable_hitbox_and_finish()
- Emit effect/VFX events and run interruption, expiry and cleanup handlers.

**Engine-neutral pseudocode**

```text
def execute_adaptive_kagune_appendages_tokyo(ctx, actor, target, cfg):
    # LORE INTENT: Eto reshapes her kagune into grotesque limbs, eyes, mouths and other appendages; her shapes are not constrained to a simple wing.
    if not ctx.owns_ability(actor, ability_id): return NOT_OWNED
    if not ctx.check_explicit_conditions(actor, target, cfg): return DENIED
    tx = ctx.begin_effect(ability_id, actor, target)
    assert allowed_combat_state(actor)
    play_attack_animation(actor,ability)
    during_active_frames: targets = sweep_weapon_or_body_hitbox(actor)
    for target in new_valid_targets(targets,hit_ledger): resolve_melee_hit(target)
    on_recovery_complete: disable_hitbox_and_finish()
    tx.commit_if_valid()
    ctx.emit_effect_event(ability_id)
    return SUCCESS
```

**Undefined balancing inputs:** attack_arc, reach, active_frames, cooldown, resource_cost, range, duration, damage_or_magnitude

## 3. Kakuja: One-Eyed Owl

**Canon effect:** Eto can deploy a monstrous armored kakuja body while retaining consciousness, increasing reach and access to large close-range attacks.

**Activation:** active_transformation · **Form:** normal_or_kagune_manifested · **Targeting:** self

**Coding logic**

- CHARACTER: Eto Yoshimura — Kakuja: One-Eyed Owl
- CANON BEHAVIOR: Eto can deploy a monstrous armored kakuja body while retaining consciousness, increasing reach and access to large close-range attacks.
- FORM REQUIREMENT: normal_or_kagune_manifested
- Check if transformation is allowed, transition normal -> kakuja.
- Swap rigs, collision capsules/hitbox sets, attack loadout and animations.
- Do not assume the transformation causes loss of player/AI control.
- Leave transformation when explicitly canceled or story/game state requires.
- IMPLEMENTATION FAMILY: Form swap state machine
- assert can_enter_form(actor,requested_form)
- transition_actor_state(actor,TRANSFORMING)
- swap_mesh_skeleton_collision_and_move_set(actor,requested_form)
- apply_only_configured_form_stat_modifiers(actor)
- on_form_end: revert_all_owned_form_changes()
- Emit effect/VFX events and run interruption, expiry and cleanup handlers.

**Engine-neutral pseudocode**

```text
def execute_kakuja_one_eyed_owl_tokyo(ctx, actor, target, cfg):
    # LORE INTENT: Eto can deploy a monstrous armored kakuja body while retaining consciousness, increasing reach and access to large close-range attacks.
    if not ctx.owns_ability(actor, ability_id): return NOT_OWNED
    if not ctx.check_explicit_conditions(actor, target, cfg): return DENIED
    tx = ctx.begin_effect(ability_id, actor, target)
    assert can_enter_form(actor,requested_form)
    transition_actor_state(actor,TRANSFORMING)
    swap_mesh_skeleton_collision_and_move_set(actor,requested_form)
    apply_only_configured_form_stat_modifiers(actor)
    on_form_end: revert_all_owned_form_changes()
    tx.commit_if_valid()
    ctx.emit_effect_event(ability_id)
    return SUCCESS
```

**Undefined balancing inputs:** form_requirements, duration, stat_changes, cooldown, resource_cost, range

## 4. Kakuja Heavy Cleave

**Canon effect:** Eto uses the large, reshaped kakuja body to cut down nearby opponents with close-range attacks.

**Activation:** active · **Form:** kakuja_form · **Targeting:** short-range enemies near front arc

**Coding logic**

- CHARACTER: Eto Yoshimura — Kakuja Heavy Cleave
- CANON BEHAVIOR: Eto uses the large, reshaped kakuja body to cut down nearby opponents with close-range attacks.
- FORM REQUIREMENT: kakuja_form
- Require kakuja_form.
- Select heavy-swing animation and trace a broad moving hitbox.
- Resolve contacts once per swing; allow collision with environment if configured.
- IMPLEMENTATION FAMILY: Form swap state machine
- assert can_enter_form(actor,requested_form)
- transition_actor_state(actor,TRANSFORMING)
- swap_mesh_skeleton_collision_and_move_set(actor,requested_form)
- apply_only_configured_form_stat_modifiers(actor)
- on_form_end: revert_all_owned_form_changes()
- Emit effect/VFX events and run interruption, expiry and cleanup handlers.

**Engine-neutral pseudocode**

```text
def execute_kakuja_heavy_cleave_tokyo(ctx, actor, target, cfg):
    # LORE INTENT: Eto uses the large, reshaped kakuja body to cut down nearby opponents with close-range attacks.
    if not ctx.owns_ability(actor, ability_id): return NOT_OWNED
    if not ctx.check_explicit_conditions(actor, target, cfg): return DENIED
    tx = ctx.begin_effect(ability_id, actor, target)
    assert can_enter_form(actor,requested_form)
    transition_actor_state(actor,TRANSFORMING)
    swap_mesh_skeleton_collision_and_move_set(actor,requested_form)
    apply_only_configured_form_stat_modifiers(actor)
    on_form_end: revert_all_owned_form_changes()
    tx.commit_if_valid()
    ctx.emit_effect_event(ability_id)
    return SUCCESS
```

**Undefined balancing inputs:** form_requirements, duration, stat_changes, cooldown, resource_cost, range

## 5. Detached Kagune Restraint

**Canon effect:** Eto detaches pieces of kagune that can act away from her body and restrain or manipulate a target.

**Activation:** active · **Form:** none_specified · **Targeting:** selected nearby or remotely reachable enemy

**Coding logic**

- CHARACTER: Eto Yoshimura — Detached Kagune Restraint
- CANON BEHAVIOR: Eto detaches pieces of kagune that can act away from her body and restrain or manipulate a target.
- FORM REQUIREMENT: none_specified
- Spawn an owned detachable kagune entity rather than a simple thrown item.
- Give it travel, seek or placed behavior and a restraint collision trigger.
- While attached, apply movement/action restrictions and enable escape/counter rules if game design allows.
- Clean up fragment if destroyed or recalled.
- IMPLEMENTATION FAMILY: Shape existing or created substance
- material = locate_or_generate_allowed_substance(material_kind, actor)
- if material is None: return NO_VALID_MATERIAL
- apply_named_transformation_or_force(material, target_shape_or_motion)
- update_collision_mass_and_attached_effects(material)
- on_release: settle_construct_under_world_physics(material)
- Emit effect/VFX events and run interruption, expiry and cleanup handlers.

**Engine-neutral pseudocode**

```text
def execute_detached_kagune_restraint_tokyo(ctx, actor, target, cfg):
    # LORE INTENT: Eto detaches pieces of kagune that can act away from her body and restrain or manipulate a target.
    if not ctx.owns_ability(actor, ability_id): return NOT_OWNED
    if not ctx.check_explicit_conditions(actor, target, cfg): return DENIED
    tx = ctx.begin_effect(ability_id, actor, target)
    material = locate_or_generate_allowed_substance(material_kind, actor)
    if material is None: return NO_VALID_MATERIAL
    apply_named_transformation_or_force(material, target_shape_or_motion)
    update_collision_mass_and_attached_effects(material)
    on_release: settle_construct_under_world_physics(material)
    tx.commit_if_valid()
    ctx.emit_effect_event(ability_id)
    return SUCCESS
```

**Undefined balancing inputs:** material_kind, control_radius, mass_limit, cooldown, resource_cost, range, duration

## 6. Kagune Transplant / RC Alteration

**Canon effect:** Eto is shown introducing kagune tissue into others and altering their physiology; mechanism and outcomes are unusually complex and case-specific.

**Activation:** special_scripted_interaction · **Form:** none_specified · **Targeting:** specific other individual

**Coding logic**

- CHARACTER: Eto Yoshimura — Kagune Transplant / RC Alteration
- CANON BEHAVIOR: Eto is shown introducing kagune tissue into others and altering their physiology; mechanism and outcomes are unusually complex and case-specific.
- FORM REQUIREMENT: none_specified
- Do not implement as an unconditional damaging projectile.
- Treat as a scripted target-dependent transformation with explicit permission, scenario and valid recipients.
- Model the result as a status/character modification only when the game designer defines which characters are eligible.
- IMPLEMENTATION FAMILY: Causal / probability rule
- event = capture_qualifying_outcome_before_commit(world)
- possibilities = derive_legal_outcomes(event, scoped_rules)
- selected = choose_or_bias_outcome(possibilities, owner, rng)
- commit_single_selected_outcome(selected)
- log_causal_branch_for_replay()
- Emit effect/VFX events and run interruption, expiry and cleanup handlers.

**Engine-neutral pseudocode**

```text
def execute_kagune_transplant_rc_alteration_tokyo(ctx, actor, target, cfg):
    # LORE INTENT: Eto is shown introducing kagune tissue into others and altering their physiology; mechanism and outcomes are unusually complex and case-specific.
    if not ctx.owns_ability(actor, ability_id): return NOT_OWNED
    if not ctx.check_explicit_conditions(actor, target, cfg): return DENIED
    tx = ctx.begin_effect(ability_id, actor, target)
    event = capture_qualifying_outcome_before_commit(world)
    possibilities = derive_legal_outcomes(event, scoped_rules)
    selected = choose_or_bias_outcome(possibilities, owner, rng)
    commit_single_selected_outcome(selected)
    log_causal_branch_for_replay()
    tx.commit_if_valid()
    ctx.emit_effect_event(ability_id)
    return SUCCESS
```

**Undefined balancing inputs:** trigger_predicate, eligible_outcomes, cooldown, resource_cost, range, duration

## 7. Ghoul Regeneration

**Canon effect:** Eto survives extreme bodily injury and regenerates significant portions of her body under story-specific conditions.

**Activation:** passive · **Form:** none_specified · **Targeting:** self

**Coding logic**

- CHARACTER: Eto Yoshimura — Ghoul Regeneration
- CANON BEHAVIOR: Eto survives extreme bodily injury and regenerates significant portions of her body under story-specific conditions.
- FORM REQUIREMENT: none_specified
- Use a dedicated regen component attached to her ghoul biology.
- Expose regen rate and what injuries are repairable as tunable parameters.
- Tie extreme events to scripted regeneration states rather than instant immortality.
- IMPLEMENTATION FAMILY: Self or target tissue repair
- if not eligible_to_regenerate(target): return
- repairable = classify_injury_parts(target)
- per_tick = compute_regeneration_amount(ability,delta_time)
- restore_health_and_allowed_body_parts(target,repairable,per_tick)
- stop_when_defeated_or_regeneration_is_suppressed()
- Emit effect/VFX events and run interruption, expiry and cleanup handlers.

**Engine-neutral pseudocode**

```text
def execute_ghoul_regeneration_tokyo(ctx, actor, target, cfg):
    # LORE INTENT: Eto survives extreme bodily injury and regenerates significant portions of her body under story-specific conditions.
    if not ctx.owns_ability(actor, ability_id): return NOT_OWNED
    if not ctx.check_explicit_conditions(actor, target, cfg): return DENIED
    tx = ctx.begin_effect(ability_id, actor, target)
    if not eligible_to_regenerate(target): return
    repairable = classify_injury_parts(target)
    per_tick = compute_regeneration_amount(ability,delta_time)
    restore_health_and_allowed_body_parts(target,repairable,per_tick)
    stop_when_defeated_or_regeneration_is_suppressed()
    tx.commit_if_valid()
    ctx.emit_effect_event(ability_id)
    return SUCCESS
```

**Undefined balancing inputs:** heal_rate, injury_types, suppression_rules, cooldown, resource_cost, range, duration

## 8. Superhuman Speed and Resilience

**Canon effect:** Eto moves too quickly for some opponents to visually track and endures extremely serious impacts.

**Activation:** passive · **Form:** none_specified · **Targeting:** self

**Coding logic**

- CHARACTER: Eto Yoshimura — Superhuman Speed and Resilience
- CANON BEHAVIOR: Eto moves too quickly for some opponents to visually track and endures extremely serious impacts.
- FORM REQUIREMENT: none_specified
- Apply character movement and hit-reaction modifiers as a stat profile.
- Allow tactical AI reposition and evasive movement.
- IMPLEMENTATION FAMILY: Movement controller override
- if not movement_state_allows(actor,ability): return DENIED
- trajectory = plan_movement_path(actor,aim_or_target,config)
- for step in trajectory: move_with_swept_collision(actor,step)
- handle_wall_floor_and_cancel_rules(actor)
- restore_standard_movement_controller_after_action(actor)
- Emit effect/VFX events and run interruption, expiry and cleanup handlers.

**Engine-neutral pseudocode**

```text
def execute_superhuman_speed_and_resilience_tokyo(ctx, actor, target, cfg):
    # LORE INTENT: Eto moves too quickly for some opponents to visually track and endures extremely serious impacts.
    if not ctx.owns_ability(actor, ability_id): return NOT_OWNED
    if not ctx.check_explicit_conditions(actor, target, cfg): return DENIED
    tx = ctx.begin_effect(ability_id, actor, target)
    if not movement_state_allows(actor,ability): return DENIED
    trajectory = plan_movement_path(actor,aim_or_target,config)
    for step in trajectory: move_with_swept_collision(actor,step)
    handle_wall_floor_and_cancel_rules(actor)
    restore_standard_movement_controller_after_action(actor)
    tx.commit_if_valid()
    ctx.emit_effect_event(ability_id)
    return SUCCESS
```

**Undefined balancing inputs:** movement_curve, speed, duration, cooldown, resource_cost, range

